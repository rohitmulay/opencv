# OpencvInstallation
Esay way to install and configure OpenCV in Ubuntu system. This shell file automatic download (internet connection required)
required file.

# Installation
1. manually download opencv *.zip file (from link http://opencv.org/ or https://github.com/Itseez/opencv)

2. placed opencv.sh file on samle directory

3. now open terminal at current directory and type ./opencv.sh

# Video tutorial
for video tutorial click on below link

'''
https://www.youtube.com/watch?v=Pwk2Oetww1k&list=PLzEIZNgHo73mXE4SsuIgWmq9UYMA394Sk
'''
